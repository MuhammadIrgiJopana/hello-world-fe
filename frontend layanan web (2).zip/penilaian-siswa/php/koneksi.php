<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "sistem_penilaian";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Koneksi database gagal");
}

?>