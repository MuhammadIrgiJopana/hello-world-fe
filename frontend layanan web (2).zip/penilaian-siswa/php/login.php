<?php

header("Content-Type: application/json");

include "koneksi.php";

$username = $_POST['nidn'] ?? '';
$password = $_POST['password'] ?? '';

$query = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE username='$username'"
);

if(mysqli_num_rows($query) > 0){

    $user = mysqli_fetch_assoc($query);

    if($password == $user['password']){

        echo json_encode([
            "status" => "success",
            "role" => $user['role']
        ]);

    }else{

        echo json_encode([
            "status" => "error",
            "message" => "Password salah"
        ]);

    }

}else{

    echo json_encode([
        "status" => "error",
        "message" => "User tidak ditemukan"
    ]);

}

?>